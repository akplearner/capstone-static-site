01_Physical
===========
Rack Plan & Cabling Record and the Server Hardware Discovery Sheet live here.

FILE NAMING CONVENTION
======================
Name every exported form and evidence file like this:

    <Client>_Wk<N>_<what-it-is>.<ext>

Examples:
    GranitePeak_Wk1_Business_Requirements.pdf
    GranitePeak_Wk2_rack-front.jpg
    GranitePeak_Wk3_topology.png

Keep the client name and week number consistent -- your Week-4 handover
package is assembled from these files.
