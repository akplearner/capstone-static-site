SERVER+ CAPSTONE -- STARTER PACK
================================
Unzip this on your freshly imaged workstation. It is the folder structure
your whole engagement files into: every form you export as PDF, and every
photo or screenshot you take, has a home below.

Each numbered folder holds one part of the record set (a README inside
each says which forms land there). Keep the documents current as you work
-- Week 4's handover package is assembled from these folders, not written
from memory.

FILE NAMING CONVENTION
======================
Name every exported form and evidence file like this:

    <Client>_Wk<N>_<what-it-is>.<ext>

Examples:
    GranitePeak_Wk1_Hardware_and_HCL.pdf
    GranitePeak_Wk2_rack-front.jpg
    GranitePeak_Wk3_topology.png

Keep the client name and week number consistent -- your Week-4 handover
package is assembled from these files.

THE ADDRESSING RULE
===================
Campus LAN:          10.10.0.0/16, gateway 10.10.10.1
Your Proxmox host:   10.10.30.T   (T = your team number; Team 1 = 10.10.30.1)
Its web console:     https://10.10.30.T:8006

vmbr0 -- management: the campus LAN above. The host lives here.

vmbr1 -- DMZ:        172.16.0.0/24, gateway 172.16.0.1
    websrv    172.16.0.10   Ubuntu + NGINX -- the public website

vmbr2 -- private:    192.168.0.0/24, gateway 192.168.0.1
    winserver 192.168.0.2    Windows Server -- AD DS, DNS, DHCP
    linuxsrv  192.168.0.3    Ubuntu -- MariaDB, database "capstone_db"
    secmon    192.168.0.4    OPTIONAL monitoring -- Prometheus / Grafana / Loki

Your team's OWN business VMs start at 192.168.0.5 in the private zone and
172.16.0.11 in the DMZ. Never at 192.168.0.4: that address belongs to the
monitoring host whether or not your team builds it, and a duplicate address
surfaces days later as an outage nobody can explain.

Later phase: vmbr2 is assigned to a physical NIC and attached to a Cisco router
+ switch -- that becomes the ONLY path for the servers to reach the internet.

The rack is 24U. There is no jump box in this build, and the website is NGINX
on websrv -- never IIS.

WHERE THE CONFIGURATION GUIDE LIVES
===================================
In the platform -- not in this pack, and not on paper. Open your course and go
to the Reference page, section "Configuration guide":

    /courses/server-plus/guide/reference#config-guide

That is the exact CLI, click-path and BIOS keystroke for every install step,
written against the addressing above. Nothing about configuration is handed out
by anyone: when the topology changes, that page changes with it, which is the
whole reason it no longer lives in a document you keep a stale copy of.

ALSO IN THIS PACK
=================
    PXE_Imaging_Student_Guide.pdf -- the Week 0 workstation imaging guide.
