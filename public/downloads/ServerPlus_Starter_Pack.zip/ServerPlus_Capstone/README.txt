SERVER+ CAPSTONE -- STARTER PACK
================================
Unzip this on your freshly imaged workstation. It is the folder structure
your whole engagement files into: every form you export as PDF, and every
photo or screenshot you take, has a home below.

Each numbered folder holds one part of the record set (a README inside
each says which forms land there). Keep the documents current as you work
-- Week 4's handover package is assembled from these folders, not written
from memory.

FILE NAMING CONVENTION
======================
Name every exported form and evidence file like this:

    <Client>_Wk<N>_<what-it-is>.<ext>

Examples:
    GranitePeak_Wk1_Business_Requirements.pdf
    GranitePeak_Wk2_rack-front.jpg
    GranitePeak_Wk3_topology.png

Keep the client name and week number consistent -- your Week-4 handover
package is assembled from these files.

THE ADDRESSING RULE
===================
Campus LAN:            10.10.0.0/16
Your Proxmox host:     10.10.30.<team>   (Team 1 = 10.10.30.1, Team 2 = .2, ...)
vmbr1 -- DMZ zone:     the website VM        (worked example 172.16.0.0/24)
vmbr2 -- private zone: Windows + Linux DB    (worked example 192.168.0.0/24)

Later phase: vmbr2 is assigned to a physical NIC and attached to a Cisco
router + switch -- that becomes the ONLY path for the servers to reach
the internet.

Also in this pack:
    PXE_Imaging_Student_Guide.pdf -- the Week 0 workstation imaging guide.

The Configuration Guide (the exact CLI for every install step) is handed
out by your instructor.
